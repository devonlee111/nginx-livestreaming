<?php
/*if (isset($_FILES["uploadFile"]) && $_FILES["uploadFile"]["error"] == 0) {
  echo "no errors";

  $file_name = $_FILES["uploadFile"]["name"];
  $file_type = $_FILES["uploadFile"]["type"];
  $file_size = $_FILES["uploadFile"]["size"];
  $file_tmp_name = $_FILES["uploadFile"]["tmp_name"];
  $file_error = $_FILES["uploadFile"]["error"];

  echo $file_name;
  echo $file_type;
  echo $file_size;
  echo $file_tmp_name;
  echo $file_error;
  }
 */

$target_dir = "/home/ubuntu/uploads/";
$target_file = $target_dir . basename($_FILES["uploadFile"]["name"]);
echo "name " . $_FILES["uploadFile"]["name"];
echo "type" . $_FILES["uploadFile"]["type"];
$uploadOk = 1;
//$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
// Check if image file is a actual image or fake image
/*
   if(isset($_POST["submit"])) {
   $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
   if($check !== false) {
   echo "File is an image - " . $check["mime"] . ".";
   $uploadOk = 1;
   } else {
   echo "File is not an image.";
   $uploadOk = 0;
   }
   }
 */
// Check if file already exists
$file_type = $_FILES["uploadFile"]["type"];
echo $target_file;

if (file_exists($target_file)) {
	echo "Sorry, file already exists.";
	$uploadOk = 0;
}

// Check file size
/*
   if ($_FILES["fileToUpload"]["size"] > 500000) {
   echo "Sorry, your file is too large.";
   $uploadOk = 0;
   }
 */
// Allow certain file formats
/*
   if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
   && $imageFileType != "gif" ) {
   echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
   $uploadOk = 0;
   }
 */

// Check if $uploadOk is set to 0 by an error
if ($uploadOk == 0) {
	echo "Sorry, your file was not uploaded.";
	// if everything is ok, try to upload file
} else {
	if (move_uploaded_file($_FILES["uploadFile"]["tmp_name"], $target_file)) {
		echo "The file ". basename( $_FILES["uploadFile"]["name"]). " has been uploaded.";
	} else {
		echo "Sorry, there was an error uploading your file.";
	}
}
?>
